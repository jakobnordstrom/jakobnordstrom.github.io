Folders:

- formulas: contains fixed bandwidth formulas over 4-regular bipartite
  graphs with n vertices on each side, where n is between 9 and 100,
  and there is an added edge.
