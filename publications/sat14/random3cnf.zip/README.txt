Folders:

- formulas: contains 3 instances of a random 3-CNF formula on n
  variables and ceil(4.5 * n) clauses, for n in the range between 21
  and 1000 with step 4.
