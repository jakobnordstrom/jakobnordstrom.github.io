Folders:

- graphs: contains 3 random instances of a 3-regular graph over n
  vertices for n in the range from 10 to 298 with step 2.

- formulas: for every graph from folder graphs contains a Tseitin
  formula with one vertex having charge 1 and others having charge 0,
  and 2 instances where charges were randomly distributed so that the
  sum of charges is odd.
