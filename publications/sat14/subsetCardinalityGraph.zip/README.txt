Folders:

- graphs: contains 3 random instances of a 4 regular graph on n
  vertices, where n is between 9 and 50, written in .dot format.

- formulas: for every instance of a random 4-regular graph from folder
  graphs contains a subset cardinality formula on the double cover of
  that graph with an added arbitrary edge.
