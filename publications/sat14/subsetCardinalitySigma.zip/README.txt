Folders:

- formulas: for every n between 6 and 60 contains 3 random instances
  of subset cardinality formulas on partitions over 4 n + 1 variables.
