benchmarks = [filename for filename in file("benchmarks.txt").read().split("\n") if filename != ""]

cats = [("PB16", "elffers", "SUMINEQ")]
cats += [("PB16", "elffers", "vertexcover-completegraph")]
cats += [("PB16", "elffers", "vertexcover-grid")]
cats += [("PB16", "elffers", "subsetcard", "fixedbandwidth")]
cats += [("PB16", "elffers", "subsetcard", "random4regular")]
cats += [("PB16", "elffers", "normalized-rand6reg")]
cats += [("PB16", "elffers", "normalized-3col")]
cats += [("PB16", "elffers", "EC_ODD_GRIDS")]
cats += [("PB16", "elffers", "EC_RANDOM_GRAPHS")]

sumSat, sumUnsat = 0, 0
sumRuntime = 0
for cat in cats:
	nSat = 0
	nUnsat = 0
	for i in range(len(benchmarks)):
		ok = True
		for tok in cat:
			if tok not in benchmarks[i]:
				ok = False
		if ok:
			verdict, runtime = file("res-sat4j-res/sat4j-res-re%d.out" % (i+1)).read().split()[:2]
			sumRuntime += float(runtime)
			if verdict == "SAT": nSat += 1
			elif verdict == "UNSAT": nUnsat += 1
	print cat, nSat, "+", nUnsat
	sumSat += nSat
	sumUnsat += nUnsat
print "Total:", sumSat, sumUnsat
#print "Runtime:", sumRuntime
