This archive contains experimental data for the paper

Jan Elffers and Jakob Nordström. Divide and Conquer: Towards Faster Pseudo-Boolean Solving. In Proceedings of the 27th International Joint Conference on Artificial Intelligence and the 23rd European Conference on Artificial Intelligence (IJCAI-ECAI '18), July 2018.

## Solvers

### RoundingSat

The Linux 64-bit binary (statically built) for this solver can be found at http://www.csc.kth.se/~jakobn/RoundingSat/roundingsat.zip.

We invoked the solver using "./roundingsat < input.opb".

### Sat4j

The source code for this solver can be found at https://gitlab.ow2.org/sat4j/sat4j. We used commit 53fc413b of the master branch.

We built the solver by typing "ant pseudo" in the root directory, which generates a file sat4j-pb.jar. We invoked the solver using:

* "java -jar sat4j-pb.jar Resolution input.opb" (for the resolution-based solver);
* "java -jar sat4j-pb.jar CuttingPlanes input.opb" (for the cutting planes-based solver);
* "java -jar sat4j-pb.jar Both input.opb" (for the solver running the resolution-based solver and the cutting planes-based solver in parallel).

### OpenWBO

The source code for this solver can be found https://github.com/sat-group/open-wbo. We used commit 89dd2fe of the master branch.

We built the solver by typing "make rs" in the root directory. We invoked the solver using "./open-wbo_static -formula=1 input.opb".

## Benchmarks

The benchmarks for the experimental evaluation can be found at http://www.cril.univ-artois.fr/PB16/ (follow the links there to the older editions to download those benchmarks).
The file benchmarks.txt also contains the names (including PB competition year) of each benchmark that was run.

## Which output file corresponds to which benchmark?

The output files are stored in the `res-*` directories.

We partitioned the benchmarks into blocks to run it on a cluster. To make the runtimes evenly divided, we randomly shuffled the list of benchmarks. Therefore, the numbering in the output files is randomly shuffled. To view the output for a certain benchmark, look up its line number in `benchmarks.txt`; the output files are the ones `*-reN.out` where `N` is the line number. For example, `res-openwbo/openwbo-re1.out` contains the output of OpenWBO for benchmark `./PB16/normalized-PB16/DEC-SMALLINT-LIN/elffers/EC_RANDOM_GRAPHS/normalized-ECrand6reg-v051-n1.opb.bz2`.

## Generating the tables that are in the paper

The Python scripts generate the numbers in the tables of the paper based on the output files:
- gentable-{roundingsat,sat4j-both,sat4j-res,openwbo}.py together generate Table 1.
- gentable-{roundingsat,sat4j-both,sat4j-res,openwbo}-PB16elffers.py together generate Table 2.
- genconflictstable.py generates Table 3.
