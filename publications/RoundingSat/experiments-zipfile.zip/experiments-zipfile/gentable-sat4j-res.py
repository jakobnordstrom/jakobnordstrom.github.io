benchmarks = [filename for filename in file("benchmarks.txt").read().split("\n") if filename != ""]

cats = [("PB05","aloul"), ("PB06","manquiho"), ("PB06","ppp-problems"), ("PB06", "uclid"), ("PB06", "liu"), ("PB06", "namasivayam")]
cats += [("PB06", "prestwich"), ("PB06", "roussel"), ("PB10", "oliveras"), ("PB11", "heinz"), ("PB11", "lopes"), ("PB12", "sroussel")]
cats += [("PB16", "elffers"), ("PB16", "nossum"), ("PB16", "quimper")]

sumSat, sumUnsat = 0, 0
sumRuntime = 0
for cat in cats:
	nSat = 0
	nUnsat = 0
	for i in range(len(benchmarks)):
		ok = True
		for tok in cat:
			if tok not in benchmarks[i]:
				ok = False
		if ok:
			verdict, runtime = file("res-sat4j-res/sat4j-res-re%d.out" % (i+1)).read().split()[:2]
			sumRuntime += float(runtime)
			if verdict == "SAT": nSat += 1
			elif verdict == "UNSAT": nUnsat += 1
	print cat, nSat, "+", nUnsat
	sumSat += nSat
	sumUnsat += nUnsat
print "Total:", sumSat, sumUnsat
#print "Runtime:", sumRuntime
