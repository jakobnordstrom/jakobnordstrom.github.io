benchmarks = file("benchmarks.txt").read().split("\n")[:-1]
def get_conflicts_RoundingSat(contents):
	return (float(contents.split()[1]), int(contents.split("\nd conflicts")[1].split()[0]))
def get_conflicts_RoundingSat_TO(contents):
	for line in reversed(contents.split("\n")):
		if line.startswith("c #Conflicts:"): return (1800.0, int(line.split()[2]))
	return (1800.0, 0)
	return (float(contents.split()[1]), int(contents.split("\nd conflicts")[1].split()[0]))
def get_conflicts_OpenWBO(contents):
	return (float(contents.split()[1]), int(contents.split("#conflicts =")[-1].split()[0]))
def get_conflicts_OpenWBO_TO(contents):
	for line in reversed(contents.split("\n")):
		if line.startswith("c conflictcount"): return (1800.0, int(line.split()[-1]))
	return (1800.0, 0)
def get_conflicts_Sat4jRes(contents):
	try:
		return (float(contents.split()[1]), int(contents.split("c conflicts		:")[-1].split()[0]))
	except:
		return (-1, -1)

cats = [("PB05","aloul"), ("PB06","manquiho"), ("PB06","ppp-problems"), ("PB06", "uclid"), ("PB06", "liu"), ("PB06", "namasivayam")]
cats += [("PB06", "prestwich"), ("PB06", "roussel"), ("PB10", "oliveras"), ("PB11", "heinz"), ("PB11", "lopes"), ("PB12", "sroussel")]
cats += [("PB16", "nossum"), ("PB16", "quimper")]

cats += [("PB16", "elffers", "vertexcover-grid")]
cats += [("PB16", "elffers", "subsetcard", "fixedbandwidth")]
cats += [("PB16", "elffers", "subsetcard", "random4regular")]
cats += [("PB16", "elffers", "normalized-rand6reg")]
cats += [("PB16", "elffers", "EC_ODD_GRIDS")]
cats += [("PB16", "elffers", "EC_RANDOM_GRAPHS")]

D = {}
for k in cats:
	if len(k) == 2: D[k] = " ".join(k)
D[("PB16", "elffers", "vertexcover-grid")] = "PB16 elffers (Vertex Cover grids)"
D[("PB16", "elffers", "subsetcard", "fixedbandwidth")] = "PB16 elffers (SubsetCard fixed bandwidth)"
D[("PB16", "elffers", "subsetcard", "random4regular")] = "PB16 elffers (SubsetCard random matrices)"
D[("PB16", "elffers", "normalized-rand6reg")] = "PB16 elffers (Perfect Matching random graphs)"
D[("PB16", "elffers", "EC_ODD_GRIDS")] = "PB16 elffers (Even Colouring odd grids)"
D[("PB16", "elffers", "EC_RANDOM_GRAPHS")] = "PB16 elffers (Even Colouring random graphs)"

for cat in cats:
	seq_RS = []
	seq_Sat4jCP = []
	seq_Sat4jRes = []
	seq_OpenWBO = []
	for i in range(len(benchmarks)):
		ok = True
		for tok in cat:
			if tok not in benchmarks[i]:
				ok = False
		if ok:
			f = file("res-roundingsat/roundingsat-re%d.out" % (i+1)).read()
			verdict = f.split()[0]
			solved_RS = False
			if verdict != "INDETERMINATE":
				solved_RS = True
				t_RS, conflicts_RS = get_conflicts_RoundingSat(f)
				if t_RS > 1:
					seq_RS.append(conflicts_RS / t_RS)
			else:
				t_RS, conflicts_RS = get_conflicts_RoundingSat_TO(f)
				seq_RS.append(conflicts_RS / t_RS)
					#print benchmarks[i], conflicts_RS, t_RS, conflicts_RS / t_RS
				#print benchmarks[i], conflicts_RS / t_RS
			f = file("res-sat4j-CP/sat4j-CP-re%d.out" % (i+1)).read()
			verdict = f.split()[0]
			#if verdict != "INDETERMINATE" and not solved_RS: print "Sat4jCP better:", benchmarks[i]
			t_Sat4jCP, conflicts_Sat4jCP = get_conflicts_Sat4jRes(f)
			if t_Sat4jCP == -1: pass # print "Sat4jCP doesn't give an answer:", benchmarks[i] # MEMOUT probably
			elif t_Sat4jCP > 1: seq_Sat4jCP.append(conflicts_Sat4jCP / t_Sat4jCP)
			f = file("res-sat4j-res/sat4j-res-re%d.out" % (i+1)).read()
			verdict = f.split()[0]
			t_Sat4jRes, conflicts_Sat4jRes = get_conflicts_Sat4jRes(f)
			if t_Sat4jRes == -1: pass # print "Sat4j res doesn't give an answer:", benchmarks[i] # MEMOUT probably
			if t_Sat4jRes > 1: seq_Sat4jRes.append(conflicts_Sat4jRes / t_Sat4jRes)
			f = file("res-openwbo-conflictcountpatch/openwbo-conflictcountpatch-re%d.out" % (i+1)).read()
			verdict = f.split()[0]
			if verdict != "INDETERMINATE":
				t_OpenWBO, conflicts_OpenWBO = get_conflicts_OpenWBO(f)
				if t_OpenWBO > 1:
					seq_OpenWBO.append(conflicts_OpenWBO / t_OpenWBO)
			else:
				t_OpenWBO, conflicts_OpenWBO = get_conflicts_OpenWBO_TO(f)
				if float(f.split()[1]) >= 1500: # discard MEMOUT's
					seq_OpenWBO.append(conflicts_OpenWBO / t_OpenWBO)
					#print benchmarks[i], conflicts_RS, t_RS, conflicts_RS / t_RS
				#print benchmarks[i], conflicts_RS / t_RS
	seq_RS.sort()
	print "|", "%55s" % D[cat],"|",
	print "%10d"%(int((sum(seq_RS)/len(seq_RS) if seq_RS!=[] else -1))),"|",
	seq_Sat4jCP.sort()
	print "%10d"%(int((sum(seq_Sat4jCP)/len(seq_Sat4jCP) if seq_Sat4jCP!=[] else -1))),"|",
	seq_Sat4jRes.sort()
	print "%10d"%(int((sum(seq_Sat4jRes)/len(seq_Sat4jRes) if seq_Sat4jRes!=[] else -1))),"|",
	seq_OpenWBO.sort()
	print "%10d"%(int((sum(seq_OpenWBO)/len(seq_OpenWBO) if seq_OpenWBO!=[] else -1))),"|"
