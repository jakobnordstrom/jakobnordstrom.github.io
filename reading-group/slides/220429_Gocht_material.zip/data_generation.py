import random

def main():
    random.seed(0)

    solvers = ["SolverA", "SolverB1", "SolverB2"]
    families = [("benchmarkA",50), ("benchmarkB",20), ("benchmarkC", 50)]
    runningtime = {
        ("SolverA", "benchmarkA"): lambda n: 2**random.uniform(-1, 1) * n ** 2 + n,
        ("SolverA", "benchmarkB"): lambda n: 2**random.uniform(-1, 1) ** 1 + n,
        ("SolverA", "benchmarkC"): lambda n: 2**random.uniform(-1, 1) * 0.001 * 2 ** n + n,

        ("SolverB1", "benchmarkA"): lambda n: 2**random.uniform(-1, 1) * 2*n ** 2 + n,
        ("SolverB1", "benchmarkB"): lambda n: 2**random.uniform(-1, 1) * 2*n ** 2 + n,
        ("SolverB1", "benchmarkC"): lambda n: 2**random.uniform(-1, 1) * 2*(n if n < 10 else 10 * n),

        ("SolverB2", "benchmarkA"): lambda n: 2**random.uniform(-1, 1) * 2 * n ** 2 + n,
        ("SolverB2", "benchmarkB"): lambda n: 2**random.uniform(-1, 1) * 2 * n ** 1 + n,
        ("SolverB2", "benchmarkC"): lambda n: 2**random.uniform(-1, 1) * 2 * (n if n < 10 else 10 * n),
    }


    print("solver","family","instance","scaling","status","time", sep=",")

    timeout = 5000

    for solver in solvers:
        for family, ninstances in families:
            for n in range(ninstances):
                n += 1
                time = runningtime[(solver,family)](n)
                status = "OK"
                if time > timeout:
                    time = "NA"
                    status = "timeout"


                print(solver,family,"%s_%i"%(family, n),n,status,time, sep=",")

if __name__ == '__main__':
    main()